import java.util.LinkedList;

public class BinaryTree {

    Node root;

    BinaryTree() {
        root = null;
    }

    void insert(int data) {
        Node newNode = new Node(data);
        if (root == null) {
            root = newNode;
        } else {
            insertRec(root, newNode);
        }
    }

    void insertRec(Node node, Node newNode) {
        if (newNode.data < node.data) {
            if (node.left == null) {
                node.left = newNode;
            } else {
                insertRec(node.left, newNode);
            }
        } else {
            if (node.right == null) {
                node.right = newNode;
            } else {
                insertRec(node.right, newNode);
            }
        }
    }

    int sumOfNodes() {
        return sumOfNodes(root);
    }

    int sumOfNodes(Node node) {
        if (node == null) {
            return 0;
        }
        return node.data + sumOfNodes(node.left) + sumOfNodes(node.right);
    }

    int countNodes() {
        return countNodes(root);
    }

    int countNodes(Node node) {
        if (node == null) {
            return 0;
        }
        return 1 + countNodes(node.left) + countNodes(node.right);
    }

    void inorder() {
        inorderRec(root);
    }

    void inorderRec(Node node) {
        if (node != null) {
            inorderRec(node.left);
            System.out.print(node.data + " ");
            inorderRec(node.right);
        }
    }

    void preorder() {
        preorderRec(root);
    }

    void preorderRec(Node node) {
        if (node != null) {
            System.out.print(node.data + " ");
            preorderRec(node.left);
            preorderRec(node.right);
        }
    }

    void postorder() {
        postorderRec(root);
    }

    void postorderRec(Node node) {
        if (node != null) {
            postorderRec(node.left);
            postorderRec(node.right);
            System.out.print(node.data + " ");
        }
    }

    void findMaxMin() {
        max = Integer.MIN_VALUE;
        min = Integer.MAX_VALUE;
        findMaxMin(root);
        System.out.println("Max value in the tree: " + max);
        System.out.println("Min value in the tree: " + min);
    }

    int max, min;

    void findMaxMin(Node node) {
        if (node != null) {
            max = Math.max(max, node.data);
            min = Math.min(min, node.data);
            findMaxMin(node.left);
            findMaxMin(node.right);
        }
    }

    // Add element to the beginning of the tree
    void addFirst(int data) {
        Node newNode = new Node(data);
        if (root == null) {
            root = newNode;
        } else {
            newNode.left = root.left;
            newNode.right = root.right;
            root = newNode;
        }
    }

    // Add element to the end of the tree
    void addLast(int data) {
        Node newNode = new Node(data);
        if (root == null) {
            root = newNode;
        } else {
            LinkedList<Node> queue = new LinkedList<>();
            queue.add(root);
            while (!queue.isEmpty()) {
                Node current = queue.remove();
                if (current.left == null) {
                    current.left = newNode;
                    break;
                } else {
                    queue.add(current.left);
                }
                if (current.right == null) {
                    current.right = newNode;
                    break;
                } else {
                    queue.add(current.right);
                }
            }
        }
    }

    // Change the value of a specific element in the tree
    void changeElement(int oldValue, int newValue) {
        changeElement(root, oldValue, newValue);
    }

    void changeElement(Node node, int oldValue, int newValue) {
        if (node != null) {
            if (node.data == oldValue) {
                node.data = newValue;
            }
            changeElement(node.left, oldValue, newValue);
            changeElement(node.right, oldValue, newValue);
        }
    }

    // Get the value of the first element in the tree
    int getFirst() {
        if (root != null) {
            return root.data;
        }
        return Integer.MIN_VALUE; // Return a default value if tree is empty
    }

    // Get the value of the last element in the tree
    int getLast() {
        if (root == null) {
            return Integer.MIN_VALUE; // Return a default value if tree is empty
        }
        Node current = root;
        while (current.right != null) {
            current = current.right;
        }
        return current.data;
    }

    // Search for a specific element in the tree
    boolean searchElement(int value) {
        return searchElement(root, value);
    }

    boolean searchElement(Node node, int value) {
        if (node == null) {
            return false;
        }
        if (node.data == value) {
            return true;
        }
        return searchElement(node.left, value) || searchElement(node.right, value);
    }

    // Search for a specific node in the tree
    Node searchNode(int value) {
        return searchNode(root, value);
    }

    Node searchNode(Node node, int value) {
        if (node == null || node.data == value) {
            return node;
        }
        Node left = searchNode(node.left, value);
        Node right = searchNode(node.right, value);
        return left != null ? left : right;
    }

    // Display all occurrences of a specific element in the tree
    void searchElementDisplay(int value) {
        searchElementDisplay(root, value);
    }

    void searchElementDisplay(Node node, int value) {
        if (node != null) {
            if (node.data == value) {
                System.out.println("Node found: " + node.data);
            }
            searchElementDisplay(node.left, value);
            searchElementDisplay(node.right, value);
        }
    }

    // Display all occurrences of a specific node in the tree
    void searchNodeDisplay(int value) {
        Node node = searchNode(value);
        if (node != null) {
            System.out.println("Node found: " + node.data);
        } else {
            System.out.println("Node not found.");
        }
    }

    // Remove a specific element from the tree
    void removeElement(int value) {
        root = removeElement(root, value);
    }

    Node removeElement(Node node, int value) {
        if (node == null) {
            return node;
        }
        if (value < node.data) {
            node.left = removeElement(node.left, value);
        } else if (value > node.data) {
            node.right = removeElement(node.right, value);
        } else {
            // Node with only one child or no child
            if (node.left == null) {
                return node.right;
            } else if (node.right == null) {
                return node.left;
            }
            // Node with two children: Get the inorder successor (smallest in the right subtree)
            node.data = minValue(node.right);
            // Delete the inorder successor
            node.right = removeElement(node.right, node.data);
        }
        return node;
    }

    int minValue(Node node) {
        int minv = node.data;
        while (node.left != null) {
            minv = node.left.data;
            node = node.left;
        }
        return minv;
    }

    public static void main(String[] args) {
        BinaryTree tree = new BinaryTree();

        tree.insert(20);
        tree.insert(9);
        tree.insert(33);
        tree.insert(3);
        tree.insert(17);
        tree.insert(22);
        tree.insert(41);
        tree.insert(1);
        tree.insert(7);
        tree.insert(28);

        System.out.println("Sum of nodes of binary tree: " + tree.sumOfNodes());
        System.out.println("Count of nodes of binary tree: " + tree.countNodes());

        System.out.println("Inorder traversal of binary tree: ");
        tree.inorder();
        System.out.println();

        System.out.println("Preorder traversal of binary tree: ");
        tree.preorder();
        System.out.println();

        System.out.println("Postorder traversal of binary tree: ");
        tree.postorder();
        System.out.println();

        System.out.println("Max and Min values in the tree: ");
        tree.findMaxMin();

        // Adding methods demonstration
        System.out.println("Adding 50 as the first element of the tree:");
        tree.addFirst(50);
        System.out.println("Inorder traversal after adding 50 at the beginning: ");
        tree.inorder();
        System.out.println();

        System.out.println("Adding 60 as the last element of the tree:");
        tree.addLast(60);
        System.out.println("Inorder traversal after adding 60 at the end: ");
        tree.inorder();
        System.out.println();

        System.out.println("Changing value of node with data 17 to 70:");
        tree.changeElement(17, 70);
        System.out.println("Inorder traversal after changing value: ");
        tree.inorder();
        System.out.println();

        System.out.println("First element in the tree: " + tree.getFirst());
        System.out.println("Last element in the tree: " + tree.getLast());

        int searchValue = 22;
        System.out.println("Searching for value " + searchValue + " in the tree: " + tree.searchElement(searchValue));

        int searchNodeValue = 41;
        System.out.println("Searching for node with data " + searchNodeValue + " in the tree:");
        tree.searchNodeDisplay(searchNodeValue);

        System.out.println("Removing node with data 9 from the tree:");
        tree.removeElement(9);
        System.out.println("Inorder traversal after removing node: ");
        tree.inorder();
    }
}
