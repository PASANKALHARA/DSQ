class Array{
	
	public static void main(String []args){
		
		int[] arra ={10,25,5,85,60};
		
		arra[2] =67;
		
		for(int i=0;i<5;i++){
			
			System.out.println("Array element "+i+" is :- "+arra[i]);
			
		}
		
		
	}
}