public class Main{
	
	public static void main(String []args){
		int nums[]={8,5,2,9,1};
		BubbleSort sort = new BubbleSort();
		sort.sortExample(nums);
	}
}