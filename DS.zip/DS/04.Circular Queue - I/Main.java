public class Main
{
    public static void main(String[] args) {
        QueueArray myQueue = new QueueArray(5);

        myQueue.enqueue(10);
        myQueue.enqueue(20);
        myQueue.enqueue(30);

        myQueue.displayData(); 


        myQueue.dequeue(); 
        int frontElement = myQueue.peek();
        System.out.println("Front element: " + frontElement); 
        myQueue.displayData(); 

        myQueue.addElement(25, 1);
        myQueue.displayData();

        int searchResult =  myQueue.searchElement(20);
        System.out.println("Index of element 20: " + searchResult);
    }
}
