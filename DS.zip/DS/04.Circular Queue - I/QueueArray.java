class QueueArray {
    private int maxSize;
    private int[] queArray;
    private int front;
    private int rear;
    private int nItems;
    public QueueArray(int q) {
        maxSize = q;
        queArray = new int[maxSize];
        front = 0;
        rear = -1;
        nItems = 0;
    }
    public boolean isEmpty() {
        return nItems == 0;
    }
    public boolean isFull() {
        return nItems == maxSize;
    }
    public int size() {
        return nItems;
    }
    public void enqueue(int x) {
        if (isFull()) {
            System.out.println("Queue is full. Cannot enqueue.");
            return;
        }

        rear = (rear + 1) % maxSize;
        queArray[rear] = x;
        nItems++;
    }
    public void dequeue() {
        if (isEmpty()) {
            System.out.println("Queue is empty. Cannot dequeue.");
            return;
        }

        int removedItem = queArray[front];
        front = (front + 1) % maxSize;
        nItems--;

        System.out.println("Dequeued item: " + removedItem);
    }
    public int peek() {
        if (isEmpty()) {
            System.out.println("Queue is empty. Cannot peek.");
            return -1;
        }

        return queArray[front];
    }
    public void displayData() {
        if (isEmpty()) {
            System.out.println("Queue is empty.");
            return;
        }

        System.out.print("Queue elements: ");
        int count = 0;
        int index = front;

        while (count < nItems) {
            System.out.print(queArray[index] + " ");
            index = (index + 1) % maxSize;
            count++;
        }

        System.out.println();
    }

    public int searchElement(int x) {
        for (int i = 0; i < nItems; i++) {
            int index = (front + i) % maxSize;
            if (queArray[index] == x) {
                return index;
            }
        }
        return -1; 
    }
    
    public void searchElementDisplay(int x) {
        System.out.print("Occurrences of " + x + " in the queue: ");
        for (int i = 0; i < nItems; i++) {
            int index = (front + i) % maxSize;
            if (queArray[index] == x) {
                System.out.print(index + " ");
            }
        }
        System.out.println();
    }
    
    public void removeElement(int x) {
        int count = 0;
        for (int i = 0; i < nItems; i++) {
            int index = (front + i) % maxSize;
            if (queArray[index] == x) {
                for (int j = index; j < nItems - 1; j++) {
                    queArray[j] = queArray[j + 1];
                }
                queArray[(rear + maxSize - count) % maxSize] = 0;
                rear = (rear - 1 + maxSize) % maxSize;
                nItems--;
                count++;
            }
        }
    }
    
    public void addElement(int x, int position) {
        if (position < 0 || position >= nItems) {
            System.out.println("Invalid position.");
            return;
        }
        if (isFull()) {
            System.out.println("Queue is full. Cannot add element.");
            return;
        }
        rear = (rear + 1) % maxSize;
        for (int i = nItems; i > position; i--) {
            queArray[(front + i) % maxSize] = queArray[(front + i - 1) % maxSize];
        }
        queArray[(front + position) % maxSize] = x;
        nItems++;
    }
    
}
