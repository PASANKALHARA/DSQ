public class MergeSor{
	public static void sort(int []arr,int left,int right){
		if(left < right){
			int mid = (left+right)/2;
			sort(arr,left,mid);
			sort(arr,mid+1,right);
			merge(arr,left,right,mid);		
		}
	}
	
	public static void merge(int []arr,int left,int right,int mid){
			
			int n1 =(mid-(left+1));
			int n2 =(right-mid);
			int leftArr[] =new int[n1];
			int rightArr[] =new int[n2];
			
			for(int x=0;x < n1;x++){
				leftArr[x] =arr[left+x];
			}
			
			for(int x=0;x < n2;x++){
				rightArr[x] =arr[mid+1+x];
			}
			
			int i=0;
			int j=0;
			int k=left;
			
			while (i < n1 && j<n2){
				if(leftArr[i] <= rightArr[i]){
					arr[k] =leftArr[i];
					i++;
				}else{
					arr[k] = rightArr[i];
					j++;
				}
				k++;
			}
			while(i<n1){
				arr[k] =leftArr[i];
				i++;
				k++;
			}
			while(i<n2){
				arr[k] =rightArr[i];
				i++;
				k++;	
			}		
			System.out.println("sorting... ");
			for(int num : arr) {
				System.out.print(num+ " ");
				}
			System.out.println();
		
	}
}