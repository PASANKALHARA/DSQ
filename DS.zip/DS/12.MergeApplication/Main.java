public class Main{
	public static void main(String []args){
		
		MergeSor sort = new MergeSor();
		int array [] ={8,5,9,1,6,7};
		
		System.out.println("Before Sorting : ");
		for(int num :array){
			System.out.print(num+" ");
		}
		sort.sort(array,3,3);
		
	}
}