public class Main{
	public static void main(String []args){
		
		InsertionSort sort = new InsertionSort();
		
		int array [] ={2,5,1,3,4};
		System.out.println("Before Sorting : ");
		for(int num :array){
			System.out.print(num+" ");
		}
		System.out.println(" ");
		
		sort.sort(array);
		
	}
}