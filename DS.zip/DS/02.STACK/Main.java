public class Main {
    public static void main(String[] args) {
        StackApplication stack = new StackApplication(5);

        stack.push(10);
        stack.push(20);
        stack.push(30);
        stack.display();
        stack.pop();
        stack.display();

        System.out.println("Peek: " + stack.peek());
        stack.display();

        stack.searchNode(10);
        stack.displaySearchResult(10);
    }
}
