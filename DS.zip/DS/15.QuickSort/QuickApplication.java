public class QuickApplication {
    public static void main(String[] args) {
        int[] array = {13, 23, 2, 78, 43, 6, 15};
        System.out.println("Array before sorting:");
        printArray(array);
        
        QuickSort quickSort = new QuickSort();
        quickSort.quickSort(array, 0, array.length - 1);
        
        System.out.println("Array after sorting:");
        printArray(array);
    }
    
    public static void printArray(int[] array) {
        for (int num : array) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}

