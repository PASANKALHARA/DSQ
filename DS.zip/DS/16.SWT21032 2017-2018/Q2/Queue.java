import java.util.Arrays;

public class Queue {

    private int maxSize;
    private int[] queArray;
    private int front;
    private int rear;
    private int nItems;

    public Queue(int n) {
        maxSize = n;
        queArray = new int[maxSize];
        front = 0;
        rear = -1;
        nItems = 0;
    }

    public boolean isEmpty() {
        return nItems == 0;
    }

    public boolean isFull() {
        return nItems == maxSize;
    }

    public int size() {
        return nItems;
    }

    public void enQueue(int x) {
        if (!isFull()) {
            rear = (rear + 1) % maxSize;
            queArray[rear] = x;
            nItems++;
        }
    }

    public void deQueue() {
        if (!isEmpty()) {
            front = (front + 1) % maxSize;
            nItems--;
        }
    }

    public int peek() {
        if (!isEmpty()) {
            return queArray[front];
        }
        return -1;
    }

    public void display() {
        if (!isEmpty()) {
            System.out.print("Queue elements are: ");
            int count = 0;
            int index = front;

            while (count < nItems) {
                System.out.print(queArray[index] + " ");
                index = (index + 1) % maxSize;
                count++;
            }
            System.out.println();
        } else {
            System.out.println("Queue is empty.");
        }
    }

    public void addHead(int x) {
        if (!isFull()) {
            if (front == 0) {
                front = maxSize - 1;
            } else {
                front--;
            }
            queArray[front] = x;
            nItems++;
        } else {
            System.out.println("Queue is full. Cannot add head.");
        }
    }

    public int getHead() {
        if (!isEmpty()) {
            return queArray[front];
        }
        return -1;
    }

    public void find() {
        if (!isEmpty()) {
            int total = Arrays.stream(queArray).sum();
            double average = (double) total / nItems;
            System.out.println("Total of elements: " + total);
            System.out.println("Average of elements: " + average);
        } else {
            System.out.println("Queue is empty. Total and average cannot be calculated.");
        }
    }

    public static void main(String[] args) {
        Queue queue = new Queue(5);
        queue.enQueue(4);
        queue.enQueue(21);
        queue.enQueue(5);
        queue.enQueue(11);
        queue.display(); // Output: Queue elements are: 4 21 5 11
        queue.addHead(30);
        queue.display(); // Output: Queue elements are: 30 4 21 5 11
        System.out.println("Head element: " + queue.getHead()); // Output: Head element: 30
        queue.find(); // Output: Total of elements: 71 Average of elements: 14.2
    }
}
