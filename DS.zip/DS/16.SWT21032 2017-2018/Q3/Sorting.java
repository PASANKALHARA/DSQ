public class Sorting {
	
	public void insertionSort(int array[]) {
		int n = array.length;
		for (int j = 1; j < n; j++) {
			int temp = array[j];
			int i = j - 1;
			while (i > -1 && array[i] > temp) {
				array[i + 1] = array[i];
				i--;
			}
			array[i + 1] = temp;
		}
		
		System.out.print("Array elements after insertion sort: ");
		for (int num : array) {
			System.out.print(num + " ");
		}
		System.out.println();
	}
	
	public void bubbleSort(int array[]){
		
		
		int size =array.length;
		for(int i=0;i<size;i++){
			for(int j=0;j<size-i-1;j++){
				if(array[j]>array[j+1]){
					int temp =array[j];
					array[j]=array[j+1];
					array[j+1]=temp;
				}
			}
			
			}
			
			System.out.print("Array element after bubble sort:");
			for (int num :array){
				System.out.print(num +"  ");
		}
		
	}
	
	
	public static void main(String[] args) {
		int[] arr1 = {12, 2, 34, 21, 1, 24};
		int[] arr2 = {16, 34, 3, 22, 12, 37};
		
		Sorting s = new Sorting();
		
		System.out.print("Array elerrerrt befbre insertion sort: ");
		for (int num : arr1) {
			System.out.print(num + " ");
		}
		System.out.println();
		
		s.insertionSort(arr1);
		
		System.out.print("Array elerrerrt befbre insertion sort: ");
		for (int num : arr2) {
			System.out.print(num + " ");
		}
		System.out.println();
		
		s.bubbleSort(arr2);
	}
}
