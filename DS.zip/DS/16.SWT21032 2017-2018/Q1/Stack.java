import java.util.HashSet;

public class Stack {
    private int maxSize;
    private int[] stackData;
    private int top;

    public Stack(int size) {
        maxSize = size;
        stackData = new int[maxSize];
        top = -1;
    }

    public boolean isEmpty() {
        return (top == -1);
    }

    public boolean isFull() {
        return (top == maxSize - 1);
    }

    public void push(int i) {
        if (!isFull()) {
            stackData[++top] = i;
        } else {
            System.out.println("\nStack is Overflow");
        }
    }

    public int getSize() {
        return top + 1;
    }

    public int pop() {
        if (!isEmpty()) {
            int poppedItem = stackData[top--];
            return poppedItem;
        } else {
            System.out.println("\nStack is Underflow");
            return -1;
        }
    }

    public int peek() {
        if (!isEmpty()) {
            return stackData[top];
        } else {
            System.out.println("\nStack is Underflow");
            return -1;
        }
    }

    // Method to find common elements between two stacks
    public static Stack findCommonElements(Stack stack1, Stack stack2) {
        Stack commonElementsStack = new Stack(Math.min(stack1.getSize(), stack2.getSize()));
        HashSet<Integer> set = new HashSet<>();

        // Store elements of stack1 in a HashSet
        for (int i = 0; i < stack1.getSize(); i++) {
            set.add(stack1.stackData[i]);
        }

        // Check elements of stack2 against the HashSet, if found, push to the commonElementsStack
        for (int i = 0; i < stack2.getSize(); i++) {
            if (set.contains(stack2.stackData[i])) {
                commonElementsStack.push(stack2.stackData[i]);
            }
        }

        return commonElementsStack;
    }

    public static void main(String[] args) {
        int[] arr = {13, 2, 78, 5, 4, 0, 0};
        int[] stack2 = {23, 13, 67, 12, 26, 5, 90};

        Stack stack1 = new Stack(arr.length);
        Stack stack = new Stack(stack2.length);

        System.out.print("Elements in Array view: ");
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }

        System.out.print("\nElements in Stack view: ");
        for (int i = 0; i < arr.length; i++) {
            if (!(arr[i] == 0)) {
                stack1.push(arr[i]);
            }
        }
		
		while (stack.peek() != -1) {
			System.out.print(stack.pop() + " ");
		}
	
		System.out.println();

        System.out.print("\nElements in Stack2 view: ");
        
		for (int i = 0; i < stack2.length; i++) {
            stack.push(stack2[i]);
        }
		
		

        Stack commonElements = findCommonElements(stack1, stack);

        System.out.print("\nCommon Elements: ");
        while (!commonElements.isEmpty()) {
            System.out.print(commonElements.pop() + " ");
        }
        System.out.println();
    }


}

