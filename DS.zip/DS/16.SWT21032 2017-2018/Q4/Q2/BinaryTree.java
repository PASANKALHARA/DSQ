
public class BinaryTree {

    Node root;

    BinaryTree() {
        root = null;
    }

    void insert(int data) {
        Node newNode = new Node(data);
        if (root == null) {
            root = newNode;
        } else {
            insertRec(root, newNode);
        }
    }

    void insertRec(Node node, Node newNode) {
        if (newNode.data < node.data) {
            if (node.left == null) {
                node.left = newNode;
            } else {
                insertRec(node.left, newNode);
            }
        } else {
            if (node.right == null) {
                node.right = newNode;
            } else {
                insertRec(node.right, newNode);
            }
        }
    }

    int sumOfNodes() {
        return sumOfNodes(root);
    }

    int sumOfNodes(Node node) {
        if (node == null) {
            return 0;
        }
        return node.data + sumOfNodes(node.left) + sumOfNodes(node.right);
    }

    int countNodes() {
        return countNodes(root);
    }

    int countNodes(Node node) {
        if (node == null) {
            return 0;
        }
        return 1 + countNodes(node.left) + countNodes(node.right);
    }

    void inorder() {
        inorderRec(root);
    }

    void inorderRec(Node node) {
        if (node != null) {
            inorderRec(node.left);
            System.out.print(node.data + " ");
            inorderRec(node.right);
        }
    }

    void preorder() {
        preorderRec(root);
    }

    void preorderRec(Node node) {
        if (node != null) {
            System.out.print(node.data + " ");
            preorderRec(node.left);
            preorderRec(node.right);
        }
    }

    void postorder() {
        postorderRec(root);
    }

    void postorderRec(Node node) {
        if (node != null) {
            postorderRec(node.left);
            postorderRec(node.right);
            System.out.print(node.data + " ");
        }
    }

    void findMaxMin() {
        findMaxMin(root);
    }

    int max, min;

    void findMaxMin(Node node) {
        if (node != null) {
            max = Math.max(max, node.data);
            min = Math.min(min, node.data);
            findMaxMin(node.left);
            findMaxMin(node.right);
        }
    }

    public static void main(String[] args) {
        BinaryTree tree = new BinaryTree();

        tree.insert(20);
        tree.insert(9);
        tree.insert(33);
        tree.insert(3);
        tree.insert(17);
        tree.insert(22);
        tree.insert(41);
        tree.insert(1);
        tree.insert(7);
        tree.insert(28);

        System.out.println("Sum of nodes of binary tree: " + tree.sumOfNodes());
        System.out.println("Count of nodes of binary tree: " + tree.countNodes());

        System.out.println("Inorder traversal of binary tree: ");
        tree.inorder();
        System.out.println();

        System.out.println("Preorder traversal of binary tree: ");
        tree.preorder();
        System.out.println();

        System.out.println("Postorder traversal of binary tree: ");
        tree.postorder();
        System.out.println();
    }
}

        
