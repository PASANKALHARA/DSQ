public class BinaryTree {

    Node root;

    BinaryTree() {
        root = null;
    }

    void insert(int data) {
        Node newNode = new Node(data);
        if (root == null) {
            root = newNode;
        } else {
            insertRec(root, newNode);
        }
    }

    void insertRec(Node node, Node newNode) {
        if (newNode.data < node.data) {
            if (node.left == null) {
                node.left = newNode;
            } else {
                insertRec(node.left, newNode);
            }
        } else {
            if (node.right == null) {
                node.right = newNode;
            } else {
                insertRec(node.right, newNode);
            }
        }
    }

    void inorder() {
        inorderRec(root);
    }

    void inorderRec(Node node) {
        if (node != null) {
            inorderRec(node.left);
            System.out.print(node.data + " ");
            inorderRec(node.right);
        }
    }

    public static void main(String[] args) {
        BinaryTree tree = new BinaryTree();

        tree.insert(20);
        tree.insert(9);
        tree.insert(33);
        tree.insert(3);
        tree.insert(17);
        tree.insert(22);
        tree.insert(41);
        tree.insert(1);
        tree.insert(7);
        tree.insert(28);

        System.out.println("Inorder traversal of binary tree: ");
        tree.inorder();
    }
}
