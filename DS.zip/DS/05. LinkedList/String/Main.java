public class Main{
	public static void main(String []args){
		LinkedList linkedList = new LinkedList();
		linkedList.insert("Emily");
		linkedList.insert("Henry");
		linkedList.insert("Sophia");
		linkedList.insert("Grace");
		linkedList.insert("Samuel");
		
		linkedList.show();
		
		System.out.println("================== Add Head Note ======================");
		linkedList.insertFirst("Olivia");
		linkedList.show();
		
		
		System.out.println("================== Add Last Note ======================");
		linkedList.insertAt("Thomas",6);
		linkedList.show();
		
		System.out.println("================== Delete index of 3 ======================");
		
		linkedList.delete(3);
		
		System.out.println("================== Show finaly ======================");
		linkedList.show();
	}
}