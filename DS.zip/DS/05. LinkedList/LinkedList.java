import java.util.NoSuchElementException;
public class LinkedList {
    Node head;

    public LinkedList() {
        head = null;
    }

    public void insert(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    public void addFirst(int data) {
        Node newNode = new Node(data);
        newNode.next = head;
        head = newNode;
    }

    public void addLast(int data) {
        insert(data);
    }

    public void changeElement(int index, int newData) {
        Node current = head;
        int count = 0;
        while (current != null) {
            if (count == index) {
                current.data = newData;
                return;
            }
            count++;
            current = current.next;
        }
        throw new IndexOutOfBoundsException("Index out of bounds.");
    }

    public int getFirst() {
        if (head == null)
            throw new NoSuchElementException("List is empty.");
        return head.data;
    }

    public int getLast() {
        if (head == null)
            throw new NoSuchElementException("List is empty.");
        Node current = head;
        while (current.next != null) {
            current = current.next;
        }
        return current.data;
    }

    public int searchElement(int data) {
        Node current = head;
        int index = 0;
        while (current != null) {
            if (current.data == data) {
                return index;
            }
            current = current.next;
            index++;
        }
        return -1;
    }

    public Node searchNode(int data) {
        Node current = head;
        while (current != null) {
            if (current.data == data) {
                return current;
            }
            current = current.next;
        }
        return null;
    }

    public void searchElementDisplay(int data) {
        int index = searchElement(data);
        if (index != -1) {
            System.out.println("Element " + data + " found at index: " + index);
        } else {
            System.out.println("Element " + data + " not found in the list.");
        }
    }

    public void searchNodeDisplay(int data) {
        Node node = searchNode(data);
        if (node != null) {
            System.out.println("Node containing element " + data + " found.");
        } else {
            System.out.println("Node containing element " + data + " not found in the list.");
        }
    }

    public void removeElement(int data) {
        if (head == null)
            return;
        if (head.data == data) {
            head = head.next;
            return;
        }
        Node current = head;
        while (current.next != null) {
            if (current.next.data == data) {
                current.next = current.next.next;
                return;
            }
            current = current.next;
        }
    }

    public void addElement(int index, int data) {
        if (index < 0)
            throw new IndexOutOfBoundsException("Index cannot be negative.");
        if (index == 0) {
            addFirst(data);
            return;
        }
        Node newNode = new Node(data);
        Node current = head;
        int count = 0;
        while (current != null) {
            if (count == index - 1) {
                newNode.next = current.next;
                current.next = newNode;
                return;
            }
            count++;
            current = current.next;
        }
        throw new IndexOutOfBoundsException("Index out of bounds.");
    }

    public void printList() {
        Node current = head;
        System.out.print("LinkedList: ");
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
}
