import java.util.NoSuchElementException;

public class Main {
    public static void main(String[] args) {
        LinkedList list = new LinkedList();
        int[] elements = {2, 4, 6, 8, 10, 12, 14, 16};
        for (int element : elements) {
            list.insert(element);
        }
        System.out.println("Original List:");
        list.printList();
        list.addFirst(0);
        list.addLast(18);
        System.out.println("\nList after adding elements at the beginning and end:");
        list.printList();
        list.changeElement(2, 100);
        System.out.println("\nList after changing an element:");
        list.printList();

        int first = list.getFirst();
        int last = list.getLast();
        System.out.println("\nFirst element: " + first);
        System.out.println("Last element: " + last);
        int elementToSearch = 12;
        int searchResult = list.searchElement(elementToSearch);
        System.out.println("\nIndex of element " + elementToSearch + ": " + searchResult);
        Node node = list.searchNode(10);
        System.out.println("\nNode containing element 10: " + node.data);
        list.removeElement(6);
        System.out.println("\nList after removing an element:");
        list.printList();
        list.addElement(3, 50);
        System.out.println("\nList after adding an element at index 3:");
        list.printList();
    }
}
