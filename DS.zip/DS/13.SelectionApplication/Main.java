public class Main {
    public static void main(String[] args) {
        SelectionSort sort = new SelectionSort();
        int nums[] = {8, 5, 2, 9, 1};
        sort.sortExample(nums);
        sort.displaySortedArray(nums);
    }
}
