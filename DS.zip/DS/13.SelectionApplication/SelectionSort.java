
public class SelectionSort {
    public void sortExample(int[] arr) {
        for (int i = 0; i < arr.length - 1; i++) {
            int smallest_index = i;
            for (int j = i; j < arr.length; j++) {
                if (arr[j] < arr[smallest_index]) {
                    smallest_index = j;
                }
            }
            int temp = arr[smallest_index];
            arr[smallest_index] = arr[i];
            arr[i] = temp;

            System.out.println();
            System.out.println((i + 1) + " Iteration :");
            for (int num : arr) {
                System.out.print(num + " ");
            }
        }
    }

    public void displaySortedArray(int[] arr) {
        System.out.println("\n\nSorted Array:");
        for (int num : arr) {
            System.out.print(num + " ");
        }
    }
}
